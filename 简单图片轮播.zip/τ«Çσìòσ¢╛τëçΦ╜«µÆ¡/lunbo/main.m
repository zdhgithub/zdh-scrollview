//
//  main.m
//  lunbo
//
//  Created by zdhmac on 16/6/6.
//  Copyright © 2016年 zdhmac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
