//
//  ZDHScrollView.h
//  lunbo
//
//  Created by zdhmac on 16/6/6.
//  Copyright © 2016年 zdhmac. All rights reserved.
//

#import <UIKit/UIKit.h>

//点击图片的回调
typedef void(^ClickBlock)(NSInteger index);


@interface ZDHScrollView : UIView
@property(nonatomic,strong)NSArray *urlArray;//保存图片网址
@property(nonatomic,assign)NSTimeInterval timeIntervel;//保存定时器间隔
@property (nonatomic, copy) ClickBlock imageClickBlock;//点击图片的回调

-(instancetype)initWithFrame:(CGRect)frame urls:(NSArray *)urlArray timeIntervel:(NSTimeInterval)timeIntervel;

@end
