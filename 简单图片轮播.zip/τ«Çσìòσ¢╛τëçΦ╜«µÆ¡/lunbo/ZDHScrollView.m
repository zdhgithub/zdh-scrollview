//
//  ZDHScrollView.m
//  lunbo
//
//  Created by zdhmac on 16/6/6.
//  Copyright © 2016年 zdhmac. All rights reserved.
//

#import "ZDHScrollView.h"
#import "UIImageView+WebCache.h"


@interface ZDHScrollView ()<UIScrollViewDelegate>
{
    UIImageView *imageView;
}
@property(nonatomic,weak)UIScrollView *scrollView;
@property(nonatomic,weak)UIPageControl *pageControl;
@end


@implementation ZDHScrollView


#pragma mark- 构造方法
- (instancetype)initWithFrame:(CGRect)frame urls:(NSArray *)urlArray timeIntervel:(NSTimeInterval)timeIntervel
{
    self = [super initWithFrame:frame];
    if (self) {
        _urlArray = urlArray;
        _timeIntervel = timeIntervel;
        [self scrollView];
        [self pageControl];
    }
    return self;
}
#pragma mark- frame相关
- (CGFloat)height {
    return self.frame.size.height;
}
- (CGFloat)width {
    return self.frame.size.width;
}
- (CGFloat)x {
    return self.frame.origin.x;
}
- (CGFloat)y {
    return self.frame.origin.y;
}
#pragma mark - 懒加载

-(UIScrollView *)scrollView{
    if (!_scrollView) {
        UIScrollView *sc = [[UIScrollView alloc] initWithFrame:self.bounds];
        [self addSubview:sc];
        sc.delegate = self;
        sc.pagingEnabled = YES;
        sc.showsHorizontalScrollIndicator = NO;
        sc.contentSize = CGSizeMake((self.urlArray.count+2) * self.width, 0);
        
        for (int i=0; i<self.urlArray.count+2; i++) {
            imageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.width *i,
                                                                                   0,
                                                                                   self.width,
                                                                                   self.height)];
            imageView.tag = i+1;
            
            
            
            
            if (0 == i) {
                [self setImageWithString:self.urlArray[self.urlArray.count-1]];
//                [imageView sd_setImageWithURL:[NSURL URLWithString:self.urlArray[self.urlArray.count-1]]];
            }else if (self.urlArray.count+1 == i) {
                [self setImageWithString:self.urlArray[0]];
//                [imageView sd_setImageWithURL:[NSURL URLWithString:self.urlArray[0]]];
            }else{
                [self setImageWithString:self.urlArray[i-1]];
//                [imageView sd_setImageWithURL:[NSURL URLWithString:self.urlArray[i-1]]];
            }

            //添加图片视图
            [sc addSubview:imageView];
            
            imageView.userInteractionEnabled = YES;
            [imageView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageClick:)]];
            
        }
        sc.contentOffset = CGPointMake(self.width, 0);//设置当前显示为第一张
        _scrollView = sc;
        [NSTimer scheduledTimerWithTimeInterval:self.timeIntervel target:self selector:@selector(timer:) userInfo:nil repeats:YES];
    }
    return _scrollView;
}
-(void)setImageWithString:(NSString *)str{
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:str]];
    imageView.image = [UIImage imageWithData:data];
}
#pragma mark 图片点击事件
- (void)imageClick:(UITapGestureRecognizer *)tap {
    if (self.imageClickBlock) {
        self.imageClickBlock(tap.view.tag);
    }
}
//0  1 2 3 4  5 index
//4  1 2 3 4  1 offset
//3  0 1 2 3  0 currentPage
-(UIPageControl *)pageControl{
    if (!_pageControl) {
        UIPageControl *page = [[UIPageControl alloc] initWithFrame:CGRectMake(self.x,
                                                                             self.height-20,
                                                                             self.width,
                                                                             20)];
        [self addSubview:page];
        page.numberOfPages = self.urlArray.count;
        page.pageIndicatorTintColor = [UIColor lightGrayColor];
        page.currentPageIndicatorTintColor = [UIColor redColor];
        [page addTarget:self action:@selector(pageChanged:) forControlEvents:UIControlEventValueChanged];
        
        _pageControl = page;
    }
    return _pageControl;
}
-(void)pageChanged:(UIPageControl *)page{
    [self.scrollView setContentOffset:CGPointMake(page.currentPage * self.width, 0)animated:YES];
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    NSInteger index = self.scrollView.contentOffset.x/self.width;
    if (0 == index) {
        [self.scrollView setContentOffset:CGPointMake(self.urlArray.count * self.width, 0) animated:NO];
        self.pageControl.currentPage = self.urlArray.count-1;
    }else if (self.urlArray.count+1 == index) {
        [self.scrollView setContentOffset:CGPointMake(self.width, 0) animated:NO];
        self.pageControl.currentPage = 0;
    }else{
        self.pageControl.currentPage = index-1;
    }
}


-(void)timer:(NSTimer *)timer{
    [self.scrollView setContentOffset:CGPointMake(self.scrollView.contentOffset.x+self.width, 0)animated:YES];
}
-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView{
    NSInteger index = self.scrollView.contentOffset.x/self.width;
    if (self.urlArray.count+1 == index) {
        [self.scrollView setContentOffset:CGPointMake(self.width, 0)animated:NO];
        self.pageControl.currentPage = 0;
    }else{
        self.pageControl.currentPage = index-1;
    }
}



@end
