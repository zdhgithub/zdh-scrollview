//
//  ViewController.m
//  lunbo
//
//  Created by zdhmac on 16/6/6.
//  Copyright © 2016年 zdhmac. All rights reserved.
//

#import "ViewController.h"
#import "ZDHScrollView.h"
#define kScreenWidth  ([UIScreen mainScreen].bounds.size.width)
#define kScreenHeight ([UIScreen mainScreen].bounds.size.height)

@interface ViewController ()
{
    UIImageView *imageView;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSArray *imageUrls = @[
                           @"http://hiphotos.baidu.com/praisejesus/pic/item/e8df7df89fac869eb68f316d.jpg",
                           @"http://pic39.nipic.com/20140226/18071023_162553457000_2.jpg",
                           @"http://file27.mafengwo.net/M00/B2/12/wKgB6lO0ahWAMhL8AAV1yBFJDJw20.jpeg"];
    ZDHScrollView *scrollView = [[ZDHScrollView alloc] initWithFrame:CGRectMake(0, 20, kScreenWidth, 300)
                                                                urls:imageUrls
                                                         timeIntervel:2.0];
    scrollView.imageClickBlock = ^(NSInteger index){
        NSLog(@"%ld",index);
    };
    [self.view addSubview:scrollView];
    
    NSLog(@"%@",[@"http://file27.mafengwo.net/M00/B2/12/wKgB6lO0ahWAMhL8AAV1yBFJDJw20.jpeg" lastPathComponent]);
    

}



@end
